import React from "react";
import SignUpComponent from "../components/login/signup.component";

const Sign = () => <SignUpComponent />;

export default Sign;
