import React from "react";
import LogInComponent from "../components/login/login.component";
import { Link } from "react-router-dom";

const Login = () => <LogInComponent />;

export default Login;
