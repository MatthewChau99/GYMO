import DefaultLayout from "./Default";
import UserLayout from "./UserLayout";

export { DefaultLayout, UserLayout };
